package dao;

import util.DBConnection;
import java.sql.*;

public class ProductDAO {

    public void addProduct(String product_name, String category, double Unit_price) {
        String sql="INSERT INTO products(product_name,Category,Unit_price) VALUES(?,?,?)";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,product_name);
            ps.setString(2,category);
            ps.setDouble(3,Unit_price);

            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }

    public void deleteProduct(int product_id) {
        String sql="DELETE FROM products WHERE id=?";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,product_id);
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }
}