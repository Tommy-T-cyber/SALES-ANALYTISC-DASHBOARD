package dashboard;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginUI extends JFrame {
    private JTextField txtUser;
    private JPasswordField txtPass;
    private final Color DARK_BODY = new Color(17, 24, 39);
    private final Color DARK_CARD = new Color(31, 41, 55);

    public LoginUI() {
        setTitle("EXECUTIVE LOGIN");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(DARK_BODY);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(new EmptyBorder(50, 40, 50, 40));

        // Logo/Title
        JLabel lblTitle = new JLabel("SALES CONTROLLER");
        lblTitle.setForeground(new Color(255, 215, 0));
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Input Fields
        txtUser = new JTextField();
        styleField(txtUser, "Username");

        txtPass = new JPasswordField();
        styleField(txtPass, "Password");

        JButton btnLogin = new JButton("ACCESS DASHBOARD");
        btnLogin.setMaximumSize(new Dimension(320, 45));
        btnLogin.setBackground(new Color(46, 204, 113));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnLogin.addActionListener(this::handleLogin);

        mainPanel.add(lblTitle);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(txtUser);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(txtPass);
        mainPanel.add(Box.createVerticalStrut(40));
        mainPanel.add(btnLogin);

        add(mainPanel);
        setVisible(true);
    }

    private void styleField(JTextField field, String title) {
        field.setMaximumSize(new Dimension(320, 35));
        field.setBackground(DARK_CARD);
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY), title, 0, 0, null, Color.LIGHT_GRAY));
    }
    private void handleLogin(ActionEvent e) {
        String user = txtUser.getText();
        String pass = new String(txtPass.getPassword());

        // Initialize the DAO
        DashboardDAO dao = new DashboardDAO();

        // Check database for credentials
        if (dao.validateUser(user, pass)) {
            this.dispose(); // Close the login window
            new DashboardUI(); // Launch the main dashboard
        } else {
            JOptionPane.showMessageDialog(this,
                    "Access Denied: Invalid Username or Password",
                    "Authentication Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginUI::new);
    }
}