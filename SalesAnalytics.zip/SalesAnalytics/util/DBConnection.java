package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import dashboard.DashboardUI;
public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/TOMMY";

    private static final String USER = "root";
    private static final String PASSWORD = "THOMPSON@2856";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}