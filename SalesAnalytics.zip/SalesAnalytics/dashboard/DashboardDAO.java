package dashboard;

import java.sql.*;
import java.util.*;

public class DashboardDAO {

    public Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/TOMMY";
        String user = "root";
        String password = "THOMPSON@2856";
        return DriverManager.getConnection(url, user, password);
    }

    public double getTotalRevenue(String filter) {
        String sql = "SELECT SUM(p.Unit_price * s.quantity) FROM sales s " +
                "JOIN products p ON s.product_id = p.product_id " + filter;
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (Exception e) { System.out.println("Revenue SQL Error: " + e.getMessage()); }
        return 0;
    }

    public int getTotalOrders(String filter) {
        String sql = "SELECT COUNT(*) FROM sales s " + filter;
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) { System.out.println("Orders SQL Error: " + e.getMessage()); }
        return 0;
    }

    public int getTotalCustomers(String filter) {
        String sql = "SELECT COUNT(DISTINCT s.customer_id) FROM sales s " + filter;
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) { System.out.println("Customer SQL Error: " + e.getMessage()); }
        return 0;
    }

    public int getTotalQuantity(String filter) {
        String sql = "SELECT SUM(s.quantity) FROM sales s " + filter;
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) { System.out.println("Qty SQL Error: " + e.getMessage()); }
        return 0;
    }

    public Map<String, Integer> topProducts(String filter) {
        Map<String, Integer> map = new LinkedHashMap<>();
        // Using 's' prefix for sale_date inside the filter is correct here
        String sql = "SELECT p.product_name, SUM(s.quantity) as qty " +
                "FROM sales s JOIN products p ON s.product_id = p.product_id " +
                filter + " GROUP BY p.product_name ORDER BY qty DESC LIMIT 10";
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString(1), rs.getInt(2));
        } catch (Exception e) {
            System.out.println("DAO Table Error (Products): " + e.getMessage());
        }
        return map;
    }

    public Map<String, Double> topCustomers(String filter) {
        Map<String, Double> map = new LinkedHashMap<>();
        // Ensure the join order matches the filter's table aliases
        String sql = "SELECT c.customer_name, SUM(p.unit_price * s.quantity) as total " +
                "FROM sales s " +
                "JOIN customers c ON s.customer_id = c.customer_id " +
                "JOIN products p ON s.product_id = p.product_id " +
                filter + " GROUP BY c.customer_name ORDER BY total DESC LIMIT 10";
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString(1), rs.getDouble(2));
        } catch (Exception e) {
            System.out.println("DAO Table Error (Customers): " + e.getMessage());
        }
        return map;
    }

    public Map<String, Double> getMonthlyRevenue(String filter) {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT MONTHNAME(s.sale_date) as mon, SUM(p.unit_price * s.quantity) as rev, MONTH(s.sale_date) as m_num " +
                "FROM sales s JOIN products p ON s.product_id = p.product_id " +
                filter + " GROUP BY mon, m_num ORDER BY m_num ASC";
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString("mon"), rs.getDouble("rev"));
        } catch (Exception e) { e.printStackTrace(); }
        return map;
    }

    public Map<String, Double> getYearlyRevenue() {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT YEAR(s.sale_date) as yr, SUM(p.unit_price * s.quantity) as rev FROM sales s " +
                "JOIN products p ON s.product_id = p.product_id GROUP BY yr ORDER BY yr ASC";
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString("yr"), rs.getDouble("rev"));
        } catch (Exception e) { e.printStackTrace(); }
        return map;
    }

    public Map<String, Double> getCategoryData(String filter) {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT p.category, SUM(p.unit_price * s.quantity) as total " +
                "FROM sales s JOIN products p ON s.product_id = p.product_id " +
                filter + " GROUP BY p.category ORDER BY total DESC";
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString("category"), rs.getDouble("total"));
        } catch (SQLException e) { System.out.println("DAO Error: " + e.getMessage()); }
        return map;
    }

    public double getPreviousMonthMetric(String selectColumn, String filter) {
        String lmFilter = filter.replace("s.sale_date", "DATE_SUB(s.sale_date, INTERVAL 1 MONTH)");
        String sql = "SELECT " + selectColumn + " FROM sales s " +
                "JOIN products p ON s.product_id = p.product_id " + lmFilter;
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (Exception e) { System.out.println("MoM Error: " + e.getMessage()); }
        return 0;
    }

    public List<String[]> getExportData(String filter) {
        List<String[]> data = new ArrayList<>();
        // SQL fetching 8 columns: ID, Customer, Category, Product, Price, Qty, Total, Date
        String sql = "SELECT s.sale_id, c.customer_name, p.category, p.product_name, p.unit_price, s.quantity, " +
                "(s.quantity * p.unit_price) as total_price, s.sale_date " +
                "FROM sales s " +
                "JOIN products p ON s.product_id = p.product_id " +
                "JOIN customers c ON s.customer_id = c.customer_id " +
                filter + " ORDER BY s.sale_date DESC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                data.add(new String[]{
                        rs.getString("sale_id"),
                        rs.getString("customer_name"),
                        rs.getString("category"),
                        rs.getString("product_name"),
                        rs.getString("unit_price"),
                        rs.getString("quantity"),
                        rs.getString("total_price"),
                        rs.getString("sale_date") // This is the 8th column
                });
            }
        } catch (SQLException e) {
            System.out.println("SQL Export Error: " + e.getMessage());
        }
        return data;
    }
    public boolean validateUser(String username, String password) {
        // We use a PreparedStatement to prevent SQL Injection (Security)
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // Returns true if a matching user is found
            }
        } catch (SQLException e) {
            System.out.println("Login Validation Error: " + e.getMessage());
            return false;
        }
    }

}