package model;

public class Product {
    private int Product_id;
    private String Product_name;
    private String Category;
    private double Unit_price;

    public Product(int Product_id, String Product_name,String Category, double Unit_price) {
        this.Product_id=Product_id;
        this.Product_name = Product_name;
        this.Unit_price = Unit_price;
    }

    public int getProduct_id() { return Product_id; }
    public String getProduct_name() { return Product_name; }
    public double getUnit_price() { return Unit_price; }

    public String toString() {
        return Product_name;
    }
}