package dao;

import util.DBConnection;
import java.sql.*;

public class CustomerDAO {

    public void addCustomer(String Customer_name,String Email,String City ) {
        String sql="INSERT INTO customers(Customer_name,Email,City) VALUES(?,?,?)";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,Customer_name);
            ps.setString(2,Email);
            ps.setString(3,City);
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }







    public void deleteCustomer(int Customer_id) {
        String sql="DELETE FROM customers WHERE Customer_id=?";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,Customer_id);
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }






}