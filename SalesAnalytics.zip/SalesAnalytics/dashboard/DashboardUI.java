package dashboard;

import org.jfree.chart.*;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.io.PrintWriter;
import java.util.Map;

public class DashboardUI extends JFrame {
    private JLabel lblRev, lblQty, lblOrders, lblCust, lblProfit, lblAOV, lblClock;
    private DefaultTableModel productModel, customerModel;
    private JPanel yearlyChartArea, monthlyChartArea, body, sidebar, header;
    private JComboBox<String> yearFilter;
    private JButton btnTheme, btnLogout, btnExport, btnMenu;
    private boolean isDarkMode = false;
    private DashboardDAO dao = new DashboardDAO();
    private Map<String, JLabel> trendMap = new HashMap<>();
    private Color bgLight = new Color(240, 242, 245), bgDark = new Color(18, 22, 28);
    private Color cardLight = Color.WHITE, cardDark = new Color(33, 39, 48);
    private Color textLight = new Color(40, 40, 40), textDark = new Color(220, 220, 220);
    private Color sidebarColor = new Color(28, 35, 43);
    private JComboBox<String>  monthFilter; // Added monthFilter
    private JPanel categoryChartArea;

    public DashboardUI() {
        setTitle("EXECUTIVE SALES CONTROLLER");
        setSize(1450, 900);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 1. Initialize Filters FIRST
        yearFilter = new JComboBox<>(new String[]{"All Years", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017"});
        yearFilter.setPreferredSize(new Dimension(130, 32));
        yearFilter.addActionListener(e -> refreshData());

        monthFilter = new JComboBox<>(new String[]{
                "All Months", "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
        });
        monthFilter.setPreferredSize(new Dimension(130, 32));
        monthFilter.addActionListener(e -> refreshData());

        // 2. Initialize the Title and Clock Label (Missing Symbol Fix)
        JLabel titleLabel = new JLabel("SALES ANALYTIC DASHBOARD"); // Declared here
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(new Color(255, 215, 0));

        lblClock = new JLabel("00:00:00  ");
        lblClock.setFont(new Font("Monospaced", Font.BOLD, 30));
        lblClock.setForeground(Color.WHITE);

        // 3. Initialize Sidebar Button and Header Panel
        btnMenu = new JButton(" ☰ ");
        btnMenu.setFont(new Font("Arial", Font.BOLD, 22));
        btnMenu.setForeground(Color.WHITE);
        btnMenu.setContentAreaFilled(false);
        btnMenu.setBorderPainted(false);
        btnMenu.addActionListener(e -> { sidebar.setVisible(!sidebar.isVisible()); revalidate(); repaint(); });

        header = new JPanel(new BorderLayout());
        header.setBackground(new Color(15, 25, 35));
        header.setPreferredSize(new Dimension(1450, 65));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(40, 50, 60)));

        // 4. Assemble the Left Header (Now titleLabel exists!)
        JPanel leftHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        leftHeader.setOpaque(false);
        leftHeader.add(btnMenu);
        leftHeader.add(titleLabel);
        leftHeader.add(yearFilter);
        leftHeader.add(monthFilter);

        header.add(leftHeader, BorderLayout.WEST);
        header.add(lblClock, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ... rest of your sidebar and body code exactly as it was ...

        sidebar = new JPanel(new GridBagLayout());
        sidebar.setBackground(sidebarColor);
        sidebar.setPreferredSize(new Dimension(240, 900));
        sidebar.setVisible(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.insets = new Insets(10, 20, 10, 20);

        btnExport = createSidebarBtn("EXPORT DATA", new Color(52, 152, 219));
        btnExport.addActionListener(e -> exportToCSV());

        btnTheme = createSidebarBtn("TOGGLE THEME", new Color(71, 82, 94));
        btnTheme.addActionListener(e -> toggleTheme());

        btnLogout = createSidebarBtn("LOGOUT", new Color(192, 57, 43));
        btnLogout.addActionListener(e -> performLogout());

        sidebar.add(btnExport, gbc);
        sidebar.add(btnTheme, gbc);
        gbc.weighty = 1.0; sidebar.add(Box.createGlue(), gbc);
        gbc.weighty = 0; sidebar.add(btnLogout, gbc);
        add(sidebar, BorderLayout.WEST);

        body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBorder(new EmptyBorder(25, 35, 25, 35));
        body.setBackground(bgLight);

        JPanel kpiRow = new JPanel(new GridLayout(1, 6, 20, 0));
        kpiRow.setOpaque(false);
        kpiRow.add(createKpiCard("REVENUE", lblRev = new JLabel("0"), new Color(46, 204, 113)));
        kpiRow.add(createKpiCard(" PROFIT", lblProfit = new JLabel("0"), new Color(39, 174, 96)));
        kpiRow.add(createKpiCard("CUSTOMERS", lblCust = new JLabel("0"), new Color(241, 196, 15)));
        kpiRow.add(createKpiCard("UNITS", lblQty = new JLabel("0"), new Color(52, 152, 219)));
        kpiRow.add(createKpiCard("ORDERS", lblOrders = new JLabel("0"), new Color(155, 89, 182)));
        kpiRow.add(createKpiCard("AVG ORDER VALUE", lblAOV = new JLabel("0"), new Color(230, 126, 34)));
        body.add(kpiRow);

        JPanel tableRow = new JPanel(new GridLayout(1, 2, 25, 0));
        tableRow.setOpaque(false);
        productModel = new DefaultTableModel(new String[]{"TOP 10 PRODUCTS", "QUANTITY"}, 0);
        customerModel = new DefaultTableModel(new String[]{"TOP 10 CUSTOMERS", "AMOUNT SPENT"}, 0);
        tableRow.add(createStyledTable(productModel));
        tableRow.add(createStyledTable(customerModel));
        body.add(Box.createVerticalStrut(25));
        body.add(tableRow);

        JPanel chartRow = new JPanel(new GridLayout(1, 2, 25, 0));
        chartRow.setOpaque(false);
        yearlyChartArea = new JPanel(new BorderLayout());
        monthlyChartArea = new JPanel(new BorderLayout());
        chartRow.add(createChartContainer("YEARLY REVENUE TREND", yearlyChartArea));
        chartRow.add(createChartContainer("MONTHLY REVENUE VRS PROFIT PERFORMANCE", monthlyChartArea));
        body.add(Box.createVerticalStrut(25));
        body.add(chartRow);

        add(body, BorderLayout.CENTER);
        startTimers();
        refreshData();
        setVisible(true);
    }

    private JPanel createStyledTable(DefaultTableModel m) {
        JTable t = new JTable(m) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.getTableHeader().setReorderingAllowed(false);
        t.setFocusable(false);

        JScrollPane scroll = new JScrollPane(t);
        JPanel p = new JPanel(new BorderLayout());
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private void updateCharts(String filter) {
        Color currentCardBg = isDarkMode ? cardDark : cardLight;
        Color currentTxt = isDarkMode ? textDark : textLight;

        // --- YEARLY TREND (BAR CHART) ---
        DefaultCategoryDataset dsY = new DefaultCategoryDataset();
        dao.getYearlyRevenue().forEach((k,v) -> dsY.addValue(v, "Revenue", k));
        JFreeChart bar = ChartFactory.createBarChart("","", "", dsY);

        BarRenderer renderer = (BarRenderer) bar.getCategoryPlot().getRenderer();
        renderer.setSeriesPaint(0, new Color(41, 128, 185));
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setShadowVisible(false);

        formatChart(bar, currentCardBg, currentTxt);
        yearlyChartArea.removeAll();
        yearlyChartArea.add(new ChartPanel(bar));

        // --- MONTHLY PERFORMANCE (THICK LINE CHART: REV AND PROFIT) ---
        DefaultCategoryDataset dsM = new DefaultCategoryDataset();
        dao.getMonthlyRevenue(filter).forEach((k, v) -> {
            dsM.addValue(v, "Revenue", k);
            dsM.addValue(v * 0.30, "Profit", k);
        });

        JFreeChart line = ChartFactory.createLineChart("","", "", dsM);
        CategoryPlot plot = line.getCategoryPlot();

        // Use LineAndShapeRenderer for thickness and dots
        LineAndShapeRenderer lineRenderer = new LineAndShapeRenderer();
        BasicStroke thickStroke = new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);

        // Apply thickness
        lineRenderer.setSeriesStroke(0, thickStroke);
        lineRenderer.setSeriesStroke(1, thickStroke);

        // Set Colors
        lineRenderer.setSeriesPaint(0, new Color(52, 152, 219)); // Revenue Blue
        lineRenderer.setSeriesPaint(1, new Color(46, 204, 113)); // Profit Green

        // Show data points
        lineRenderer.setSeriesShapesVisible(0, true);
        lineRenderer.setSeriesShapesVisible(1, true);

        plot.setRenderer(lineRenderer);
        formatChart(line, currentCardBg, currentTxt);

        if (line.getLegend() != null) {
            line.getLegend().setVisible(true);
            line.getLegend().setBackgroundPaint(currentCardBg);
            line.getLegend().setItemPaint(currentTxt);
        }

        monthlyChartArea.removeAll();
        monthlyChartArea.add(new ChartPanel(line));

        revalidate();
        repaint();
    }

    private void formatChart(JFreeChart chart, Color bg, Color txt) {
        chart.setBackgroundPaint(bg);
        CategoryPlot cp = chart.getCategoryPlot();
        cp.setBackgroundPaint(bg);
        cp.setOutlineVisible(false);
        cp.setRangeGridlinesVisible(!isDarkMode);
        cp.getDomainAxis().setTickLabelPaint(txt);
        cp.getRangeAxis().setTickLabelPaint(txt);
        if (chart.getLegend() != null) chart.getLegend().setBackgroundPaint(bg);
    }

    private void toggleTheme() {
        isDarkMode = !isDarkMode;
        Color cardBg = isDarkMode ? cardDark : cardLight;
        Color txtColor = isDarkMode ? textDark : textLight;
        body.setBackground(isDarkMode ? bgDark : bgLight);
        applyThemeToAll(body, cardBg, txtColor);
        refreshData();
    }

    private void applyThemeToAll(Container parent, Color cardBg, Color txtColor) {
        for (Component c : parent.getComponents()) {
            if (c instanceof JPanel && c != body) c.setBackground(cardBg);
            if (c instanceof JLabel && !c.equals(lblClock)) c.setForeground(txtColor);
            if (c instanceof JScrollPane) {
                ((JScrollPane)c).getViewport().setBackground(cardBg);
                applyThemeToAll(((JScrollPane)c).getViewport(), cardBg, txtColor);
            }
            if (c instanceof JTable) {
                ((JTable)c).setBackground(cardBg);
                ((JTable)c).setForeground(txtColor);
            }
            if (c instanceof Container) applyThemeToAll((Container) c, cardBg, txtColor);
        }
    }
    private JPanel createKpiCard(String t, JLabel v, Color sideColor) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(isDarkMode ? cardDark : cardLight);
        p.setBorder(BorderFactory.createCompoundBorder(new LineBorder(Color.LIGHT_GRAY),
                BorderFactory.createMatteBorder(0, 5, 0, 0, sideColor)));

        v.setFont(new Font("Segoe UI", Font.BOLD, 22));
        v.setForeground(isDarkMode ? sideColor.brighter() : sideColor.darker());

        JLabel title = new JLabel(t);
        title.setFont(new Font("Segoe UI", Font.BOLD, 12));

        // NEW TREND LABEL
        JLabel trend = new JLabel("0% vs LM");
        trend.setFont(new Font("Segoe UI", Font.BOLD, 11));
        trendMap.put(t, trend);

        JPanel center = new JPanel(new GridLayout(2, 1));
        center.setOpaque(false);
        center.add(v);
        center.add(trend);

        p.add(title, BorderLayout.NORTH);
        p.add(center, BorderLayout.CENTER);
        p.setBorder(BorderFactory.createCompoundBorder(p.getBorder(), new EmptyBorder(10, 15, 10, 15)));
        return p;
    }

    private JPanel createChartContainer(String t, JPanel inner) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(isDarkMode ? cardDark : cardLight);
        JLabel l = new JLabel("  " + t);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(new Color(155, 89, 182));
        p.add(l, BorderLayout.NORTH);
        p.add(inner, BorderLayout.CENTER);
        return p;
    }

    private void startTimers() {
        new javax.swing.Timer(1000, e -> lblClock.setText(new SimpleDateFormat("HH:mm:ss").format(new java.util.Date()) + "  ")).start();
        new javax.swing.Timer(10000, e -> refreshData()).start();
    }
    private void refreshData() {
        // 1. Chart & Table Filter (Year only - as you requested)
        String yearOnlyFilter = yearFilter.getSelectedItem().equals("All Years")
                ? " WHERE 1=1 "
                : " WHERE YEAR(s.sale_date) = " + yearFilter.getSelectedItem();

        // 2. KPI Filter (Year + Month)
        String kpiFilter = yearOnlyFilter;
        if (!monthFilter.getSelectedItem().equals("All Months")) {
            kpiFilter += " AND MONTHNAME(s.sale_date) = '" + monthFilter.getSelectedItem() + "'";
        }

        // 3. Get CURRENT KPI Data using the kpiFilter
        double rev = dao.getTotalRevenue(kpiFilter);
        int orders = dao.getTotalOrders(kpiFilter);
        int qty = dao.getTotalQuantity(kpiFilter);
        int cust = dao.getTotalCustomers(kpiFilter);

        // 4. Update Main Labels
        lblRev.setText("GHS " + formatCompact(rev));
        lblProfit.setText("GHS " + formatCompact(rev * 0.30));
        lblOrders.setText(formatCompact(orders));
        lblQty.setText(formatCompact(qty));
        lblCust.setText(formatCompact(cust));
        lblAOV.setText("GHS " + formatCompact(orders > 0 ? rev / orders : 0));

        // 5. Update Tables and Charts using ONLY the yearOnlyFilter
        productModel.setRowCount(0);
        dao.topProducts(yearOnlyFilter).forEach((k,v) -> productModel.addRow(new Object[]{k, formatCompact(v)}));
        customerModel.setRowCount(0);
        dao.topCustomers(yearOnlyFilter).forEach((k,v) -> customerModel.addRow(new Object[]{k, "GHS " + formatCompact(v)}));
        updateCharts(yearOnlyFilter);

        // 6. Trends (Calculated based on the KPI filter)
        double pRev = dao.getPreviousMonthMetric("SUM(p.Unit_price * s.quantity)", kpiFilter);
        double pOrd = dao.getPreviousMonthMetric("COUNT(*)", kpiFilter);
        double pQty = dao.getPreviousMonthMetric("SUM(s.quantity)", kpiFilter);
        double pCst = dao.getPreviousMonthMetric("COUNT(DISTINCT s.customer_id)", kpiFilter);

        applyTrend(trendMap.get("REVENUE"), rev, pRev);
        applyTrend(trendMap.get("ORDERS"), (double)orders, pOrd);
        applyTrend(trendMap.get("UNITS"), (double)qty, pQty);
        applyTrend(trendMap.get("CUSTOMERS"), (double)cust, pCst);
        applyTrend(trendMap.get(" PROFIT"), rev * 0.3, pRev * 0.3);
    }
    private String formatCompact(double v) {
        if (v >= 1000000) return String.format("%.1fM", v / 1000000.0);
        if (v >= 1000) return String.format("%.1fK", v / 1000.0);
        return String.format("%.0f", v);
    }

    private void exportToCSV() {
        String selected = yearFilter.getSelectedItem().toString();
        String filter = selected.equals("All Years") ? " WHERE 1=1 " : " WHERE YEAR(s.sale_date) = " + selected;

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("EXPORT EXECUTIVE SALES DATA");
        chooser.setSelectedFile(new java.io.File("Executive_Report_" + selected + ".csv"));

        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            java.io.File destination = chooser.getSelectedFile();

            try (PrintWriter pw = new PrintWriter(destination)) {
                // Updated Headers: Added "Sale Date" at the end
                pw.println("Sale ID,Customer Name,Category,Product Name,Unit Price (GHS),Quantity,Total (GHS),Sale Date");

                List<String[]> reportData = dao.getExportData(filter);

                for (String[] row : reportData) {
                    // SaleID, Customer, Category, Product, UnitPrice, Qty, Total, Date
                    pw.printf("%s,\"%s\",\"%s\",\"%s\",%s,%s,%s,%s\n",
                            row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]);
                }

                JOptionPane.showMessageDialog(this, "Export Successful! 8 columns saved.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Export Failed: " + ex.getMessage());
            }
        }
    }

    private JButton createSidebarBtn(String t, Color c) { JButton b = new JButton(t); b.setBackground(c); b.setForeground(Color.WHITE); return b; }
    private void performLogout() { if(JOptionPane.showConfirmDialog(this,"Exit Dashboard?")==0) dispose(); }
    public static void main(String[] args) { new DashboardUI(); }

    private void applyTrend(JLabel lbl, double cur, double prev) {
        if (lbl == null || prev <= 0) {
            if(lbl != null) lbl.setText("0.0% vs LM");
            return;
        }
        double p = ((cur - prev) / prev) * 100;
        lbl.setText(String.format("%s%.1f%% vs LM", (p >= 0 ? "▲ " : "▼ "), Math.abs(p)));
        lbl.setForeground(p >= 0 ? new Color(46, 204, 113) : new Color(231, 76, 60));
    }
}