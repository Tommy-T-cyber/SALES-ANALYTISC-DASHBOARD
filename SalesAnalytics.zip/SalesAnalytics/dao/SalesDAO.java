package dao;

import model.Sale;
import util.DBConnection;

import java.sql.*;

public class SalesDAO {

    public void addSale(Sale sale) {

        String sql = "INSERT INTO sales(customer_id, product_id, quantity, sale_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, sale.getCustomerId());
            stmt.setInt(2, sale.getProductId());
            stmt.setInt(3, sale.getQuantity());
            stmt.setDate(4, java.sql.Date.valueOf(sale.getSaleDate()));

            stmt.executeUpdate();
            System.out.println("Sale added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static class AnalyticsData {
        public double totalRevenue;
        public int totalCustomers;
        public int totalOrders;

        public static AnalyticsData getSummary() {
            AnalyticsData data = new AnalyticsData();
            // SQL to get Total Revenue, Unique Customers, and Order Count
            String sql = "SELECT " +
                    "SUM(total_amount) as rev, " +
                    "COUNT(DISTINCT customer_id) as custCount, " +
                    "COUNT(sale_id) as orderCount " +
                    "FROM sales";

            try (Connection conn = DBConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                if (rs.next()) {
                    data.totalRevenue = rs.getDouble("rev");
                    data.totalCustomers = rs.getInt("custCount");
                    data.totalOrders = rs.getInt("orderCount");
                }
            } catch (SQLException e) { e.printStackTrace(); }
            return data;
        }
    }




}