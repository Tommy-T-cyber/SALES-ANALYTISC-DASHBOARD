package model;

import java.time.LocalDate;

public class Sale {
   // private int sale_id;
    private int customerId;
    private int productId;
    private int quantity;
    private LocalDate saleDate;

    public Sale(int customerId, int productId, int quantity, LocalDate saleDate) {
        this.customerId = customerId;
        this.productId = productId;
        this.quantity = quantity;
        this.saleDate = saleDate;
    }

   // public int getSales_id() {return sale_id;}
    public int getCustomerId() { return customerId; }
    public int getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public LocalDate getSaleDate() { return saleDate; }
}