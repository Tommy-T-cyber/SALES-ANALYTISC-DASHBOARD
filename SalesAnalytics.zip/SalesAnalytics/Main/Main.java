package Main;



import dashboard.LoginUI;
import ui.SalesForm;
//port dashboard.DashboardUI;
import javax.swing.*;
import dashboard.DashboardUI;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginUI::new);



    }







}