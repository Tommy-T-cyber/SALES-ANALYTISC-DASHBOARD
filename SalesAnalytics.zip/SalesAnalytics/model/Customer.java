package model;

public class Customer {
    private int Customer_id;
    private String Customer_name;
    private String Email;
    private String City;

    public Customer(int Customer_id, String Customer_name,String Email,String City) {
        this.Customer_id = Customer_id;
        this.Customer_name = Customer_name;
        this.Email=Email;
        this.City=City;
    }

    public int getCustomer_id() { return Customer_id; }
    public String getCustomer_name() { return Customer_name;}
    public String getEmail() {return Email;}
    public String getCity() {return City;}





    public String toString() {
        return Customer_name;
    }
}