package ui;

import dao.SalesDAO;
import model.Sale;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class SalesForm extends JDialog {

    private JTextField txtCustomer = new JTextField();
    private JTextField txtProduct = new JTextField();
    private JTextField txtQty = new JTextField();
    private JTextField SalesDate= new JTextField();

    private final SalesDAO dao = new SalesDAO();

    public SalesForm(JFrame parent) {
        super(parent, "New Sale", true);

        setLayout(new GridLayout(4,2,10,10));

        add(new JLabel("Customer ID:"));
        add(txtCustomer);

        add(new JLabel("Product ID:"));
        add(txtProduct);

        add(new JLabel("Quantity:"));
        add(txtQty);


        JButton saveBtn = new JButton("Save Sale");
        add(saveBtn);

        saveBtn.addActionListener(e -> saveSale());

        setSize(300,200);
        setLocationRelativeTo(parent);
    }

    private void saveSale() {
        Sale sale = new Sale(
               // Integer.parseInt(txtsale.getText()),
                Integer.parseInt(txtCustomer.getText()),
                Integer.parseInt(txtProduct.getText()),
                Integer.parseInt(txtQty.getText()),
                LocalDate.now()
        );

        dao.addSale(sale);
        dispose();
    }

    public JTextField getSalesDate() {
        return SalesDate;
    }

    public void setSalesDate(JTextField salesDate) {
        SalesDate = salesDate;
    }
}